import React,{Component} from 'react';

export default class App extends Component{

  componentDidMount(){

    this.props.getData();

  }

  render (){

    console.log("props value :",this.props.fetch_data);

    console.log("error values :", this.props.error_values);

    return(

      <div style={{marginLeft:"80px"}}><h1 >APP</h1>

        <h2 >{this.props.fetch_data.map(u=>

        (

          <p>{u.id}.{u.name},{u.email}</p>

        ))}</h2>

         <h2 >

          {this.props.error_values.status}

        </h2>

      </div>

     



    )



  }



}