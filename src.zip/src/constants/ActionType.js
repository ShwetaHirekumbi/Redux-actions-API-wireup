export const GET_DATA ="GET_DATA";
export const U_ERROR= "U_ERROR"